# Forex Trading Website

This is a simple website for introducing users to forex trading.

## Getting Started

To view the website, simply open the `index.html` file in a web browser.

## Built With

- HTML

## Authors

- [FanisaVanessaChabangu] - Initial work

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
